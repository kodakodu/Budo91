<?php
	/**
	 * 
	 */
	class model_clubs extends CI_Model {
		protected $table = 'clubs';
		
		function get_clubs() {
			return $this->db->select('*')
			->from($this->table)
			->get()
			->result();
			
		}
		
		function count_clubs(){
			return $this->db->count_all("clubs");
		}
	}
	