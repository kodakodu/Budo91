<div style="width:20% ; margin-bottom: 50px; margin-top: 50px; text-align: center; background-color: #F5F6CE">

	Novitates autem si spem adferunt, ut tamquam in herbis non fallacibus fructus appareat, non sunt illae quidem repudiandae, vetustas tamen suo loco conservanda; maxima est enim vis vetustatis et consuetudinis.

</div>