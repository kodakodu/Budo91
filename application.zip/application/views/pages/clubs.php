<div style="width:20% ; margin-bottom: 50px; margin-top: 50px; text-align: center; background-color: #F5F6CE">
	Clubs</br>
	
	locis ipsis delectemur, montuosis etiam et silvestribus, in quibus diutius commorati sumus.
	<?php
	//var_dump($data["disciplines_info"]);
		//foreach($data as $d){
		//	echo ($d);
		//}
	?>
	
	<?php foreach($clubs_liste as $c): ?>
<div id="num_<?php echo $c->id; ?>" class="message">
<p>
<a href="#num_<?php echo $c->id; ?>">#</a>
Par <span class="pseudo_commentaire"><?php echo
htmlentities($c->nom); ?></span>

</p>
<!--<div class="contenu_commentaire"><?php echo
nl2br(htmlentities($d->d)); ?></div>
</div>-->

<?php endforeach; ?>

<?php
	echo "Nombre de clubs : ". $count_clubs;
?>
</div>